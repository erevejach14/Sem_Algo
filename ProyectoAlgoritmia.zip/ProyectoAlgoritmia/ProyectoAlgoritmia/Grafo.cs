﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoAlgoritmia
{
    public class Grafo : List<Vertice>
    {
        public Grafo(ListaProblemas NuevaLista, Nodo lista)
        {
            List<string> ciudadesActuales = new List<string>();

            for (int i = 0; i < NuevaLista.Count; i++)
            {
                if (!ciudadesActuales.Contains(NuevaLista[i].origen.ToString()))
                {
                    ciudadesActuales.Add(NuevaLista[i].origen.ToString());
                }
                if (!ciudadesActuales.Contains(NuevaLista[i].destino.ToString()))
                {
                    ciudadesActuales.Add(NuevaLista[i].destino.ToString());
                }
            }
            for (int i = 0; i < ciudadesActuales.Count; i++)
            {
                ListaAristas aristasActuales = new ListaAristas();
                for (int j = 0; j < NuevaLista.Count; j++)
                {
                    if (ciudadesActuales[i] == NuevaLista[j].origen.ToString())
                    {
                        Arista arista = new Arista(NuevaLista[j].destino.ToString(), NuevaLista[j].ponderacion);
                        aristasActuales.Add(arista);
                    }
                }
                Vertice vertice = new Vertice(ciudadesActuales[i], ref aristasActuales);
                this.Add(vertice);
            }

        }
    }
}
