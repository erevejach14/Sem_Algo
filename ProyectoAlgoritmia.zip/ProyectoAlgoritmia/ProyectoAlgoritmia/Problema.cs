﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoAlgoritmia
{
    public class Problema
    {
        public string problema, origen, destino;
        public int ponderacion; 
        public Problema (string problema, int ponderacion, string origen, string destino )
        {
            this.problema = problema;
            this.ponderacion = ponderacion;
            this.origen = origen;
            this.destino = destino; 
        }
    }
}
