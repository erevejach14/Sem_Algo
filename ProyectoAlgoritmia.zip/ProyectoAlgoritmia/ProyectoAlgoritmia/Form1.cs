﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D; 
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoAlgoritmia
{
    public partial class Formulario : Form
    {
        ListaProblemas listaProblemas = new ListaProblemas();
        ListaProblemas listaSeleccionados = new ListaProblemas();
        ListaProblemas listaTemporal = new ListaProblemas();
        ListaSoluciones listaSoluciones = new ListaSoluciones();
        ListaNodos lista = new  ListaNodos();
        Grafo grafoActual; 

        int x, y;
        PaintEventArgs a, es;

        Image fondo = Image.FromFile(Environment.GetFolderPath(Environment.SpecialFolder.Personal) + @"\Computación\Tercer semestre\Algoritmia\Aerolinea - Entregable 4\Aerolinea\mapa5.jpg");


        public Formulario(ref ListaProblemas listaProblemas, ref ListaSoluciones listaSoluciones)
        {

            this.listaProblemas = listaProblemas;
            this.listaSoluciones = listaSoluciones;
            listaTemporal = listaSeleccionados; 
            InitializeComponent();
        }


        void actualizar()
        {
            for (int i = 0; i < listaSeleccionados.Count(); i++)
            {
                listBox2.Items.Add(listaSeleccionados[i].problema);
            }
        }

        private void Formulario_Load(object sender, EventArgs e)
        {
            for(int i=0; i<listaProblemas.Count(); i++)
            {
               
                listBox1.Items.Add(listaProblemas[i].problema);
            }
 
        }


        private void button1_Click(object sender, EventArgs e)
        {
            int indice = listBox1.SelectedIndex;
            listaSeleccionados.Add(listaProblemas[indice]);
            listBox2.Items.Clear();
            actualizar();
            int total=0; 

            for (int i=0; i<listaSeleccionados.Count(); i++)
            {
                total = total + listaSeleccionados[i].ponderacion; 
            }

            label1.Text = total.ToString(); 
        }

        private void panel1_MouseClick(object sender, MouseEventArgs e)
        {

            Pen lapiz = new Pen(Color.Pink, 2);
            Pen lapizLinea = new Pen(Color.DarkBlue, 1);
            Rectangle cuadrito = new Rectangle(e.X - 15, e.Y - 15, 30, 30);
            this.panel1_Paint(sender, a);
            panel1.CreateGraphics().DrawRectangle(lapiz, cuadrito);

            x = e.X;
            y = e.Y;


        }

        private void panel1_MouseClick_1(object sender, MouseEventArgs e)
        {
            Pen lapiz = new Pen(Color.Pink, 2);
            Pen lapizLinea = new Pen(Color.DarkBlue, 1);
            Rectangle cuadrito = new Rectangle(e.X - 15, e.Y - 15, 30, 30);
            this.panel1_Paint(sender, a);
            panel1.CreateGraphics().DrawRectangle(lapiz, cuadrito);

            x = e.X;
            y = e.Y;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.panel1_Paint(sender, es);
            listBox1.Items.Clear();
            listaSeleccionados.quicksortTiempo(ref listaSeleccionados, 0, listaSeleccionados.Count - 1);
            List<string> conexiones = new List<string>();
            ListaProblemas listaPrometedora = new ListaProblemas();
            Font letra = new Font("Typo_Pororo B", 12);
            SolidBrush color = new SolidBrush(Color.Black);
            Pen lapiz = new Pen(Color.Yellow, 3);
            AdjustableArrowCap flecha = new AdjustableArrowCap(4, 6);
            lapiz.CustomEndCap = flecha;

            for (int i = 0; i < grafoActual.Count; i++)
            {
                conexiones.Add(grafoActual[i].origen);
            }
            for (int i = 0; i < listaTemporal.Count; i++)
            {
                for (int j = 0; j < conexiones.Count; j++)
                {
                    if (conexiones[j].Contains(listaTemporal[i].origen.ToString()) && !conexiones[j].Contains(listaTemporal[i].destino.ToString()))
                    {
                        for (int k = 0; k < conexiones.Count; k++)
                        {
                            if (conexiones[k].Contains(listaTemporal[i].destino.ToString()) && !conexiones[k].Contains(listaTemporal[i].origen.ToString()))
                            {
                                if (listaPrometedora.Count > 0)
                                {
                                    bool esDestino = false;
                                    for (int l = 0; l < listaPrometedora.Count; l++)
                                    {
                                        if (listaTemporal[i].destino == listaPrometedora[l].destino)
                                        {
                                            esDestino = true;
                                        }
                                    }
                                    if (!esDestino)
                                    {
                                        listaPrometedora.Add(listaTemporal[i]);
                                        conexiones[j] = conexiones[j] + conexiones[k];
                                        conexiones.Remove(conexiones[k]);
                                        break;
                                    }
                                }
                                else
                                {
                                    listaPrometedora.Add(listaTemporal[i]);
                                    conexiones[j] = conexiones[j] + conexiones[k];
                                    conexiones.Remove(conexiones[k]);
                                    break;
                                }
                            }
                        }
                    }
                }
            }
            for (int i = 0; i < listaTemporal.Count; i++)
            {
                for (int j = 0; j < listaPrometedora.Count; j++)
                {
                    if (listaPrometedora[j].origen == lista[i].nombre)
                    {
                        for (int k = 0; k < lista.Count; k++)
                        {
                            if (listaPrometedora[j].destino == lista[k].nombre)
                            {
                                panel1.CreateGraphics().DrawLine(lapiz, lista[i].x + 15, lista[i].y + 15, lista[k].x + 15, lista[k].y + 15);


                            }
                        }
                    }
                }
            }

    /*        for (int i = 0; i < lista.Count; i++)
            {
                for (int j = 0; j < ListaProblemas.Count; j++)
                {
                    if (NuevaLista[j].origen == listaCiudades[i].nombre)
                    {
                        for (int k = 0; k < listaCiudades.Count; k++)
                        {
                            if (NuevaLista[j].destino == listaCiudades[k].nombre)
                            {
                                panel1.CreateGraphics().DrawString(NuevaLista[j].duracion.ToString(), letra, color, (listaCiudades[i].x + listaCiudades[k].x) / 2, (listaCiudades[i].y + listaCiudades[k].y) / 2);


                            }
                        }
                    }
                }
            }*/
        }

        private void button2_Click(object sender, EventArgs e)
        {

                Nodo nodo = new Nodo(textBox1.Text, x, y);
                lista.Add(nodo);
       

        }



        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            Pen lapiz = new Pen(Color.Magenta, 2);
            Pen lapizLinea = new Pen(Color.DarkBlue, 1);
            Font letras = new Font("Typo_Pororo B", 13);
            Font letras1 = new Font("Typo_Pororo B", 11);

            SolidBrush colorcito = new SolidBrush(Color.Black);
            SolidBrush colorcito1 = new SolidBrush(Color.Pink);

            AdjustableArrowCap flecha = new AdjustableArrowCap(3, 5);
            lapizLinea.CustomEndCap = flecha;

            panel1.CreateGraphics().DrawImageUnscaled(fondo, 0, 0);

            for (int j = 0; j < listaSeleccionados.Count; j++)
            {
                for (int k = 0; k < lista.Count; k++)
                {
                    if (listaSeleccionados[j].origen == lista[k].nombre)
                    {
                        for (int l = 0; l < lista.Count; l++)
                        {
                            if (listaSeleccionados[j].destino == lista[l].nombre)
                            {
                                panel1.CreateGraphics().DrawLine(lapizLinea, lista[k].x + 15, lista[k].y + 15, lista[l].x + 15, lista[l].y + 15);

                            }
                        }
                    }
                }
            }

            for (int i = 0; i < lista.Count; i++)
            {
                Rectangle cuadrito = new Rectangle(lista[i].x, lista[i].y, 30, 30);
                panel1.CreateGraphics().DrawRectangle(lapiz, cuadrito);
                panel1.CreateGraphics().DrawString(lista[i].nombre.ToString(), letras, colorcito, lista[i].x + 6, lista[i].y + 6);

            }

            for (int i = 0; i < lista.Count; i++)
            {
                Rectangle cuadrito = new Rectangle(lista[i].x, lista[i].y, 30, 30);
                panel1.CreateGraphics().DrawRectangle(lapiz, cuadrito);
                panel1.CreateGraphics().DrawString(lista[i].nombre.ToString(), letras1, colorcito1, lista[i].x + 7, lista[i].y + 6);

            }

            for (int i = 0; i < lista.Count; i++)
            {
                for (int j = 0; j < listaSeleccionados.Count; j++)
                {
                    if (listaSeleccionados[j].origen == lista[i].nombre)
                    {
                        for (int k = 0; k < lista.Count; k++)
                        {
                            if (listaSeleccionados[j].destino == lista[k].nombre)
                            {
                                panel1.CreateGraphics().DrawString(listaSeleccionados[j].ponderacion.ToString(), letras, colorcito, (lista[i].x + lista[k].x) / 2, (lista[i].y + lista[k].y) / 2);


                            }
                        }
                    }
                }
            }
        }
    }
}
