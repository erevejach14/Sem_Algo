﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing; 
using System.Threading.Tasks;

namespace ProyectoAlgoritmia
{
    public class Vertice
    {
        public string origen;
        public ListaAristas aristasActuales;
        public Point coordenada;
        public Vertice(string origen, ref ListaAristas aristasActuales)
        {
            this.origen = origen;
            this.aristasActuales = new ListaAristas();
            this.aristasActuales = aristasActuales;
        }
    }
}
