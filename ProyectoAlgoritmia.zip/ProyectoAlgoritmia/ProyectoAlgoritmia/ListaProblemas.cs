﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoAlgoritmia
{
   public class ListaProblemas:List<Problema>
    {
        public void quicksortTiempo(ref ListaProblemas NuevaLista, int inicio, int fin)
        {
            int i = inicio;
            int j = fin;
            int central;
            int pivote;

            central = (inicio + fin) / 2;
            pivote = NuevaLista[central].ponderacion;

            if (inicio >= fin)
            {
                return;
            }

            while (i <= j)
            {
                while (NuevaLista[i].ponderacion < pivote)
                {
                    i++;
                }
                while (NuevaLista[j].ponderacion > pivote)
                {
                    j--;
                }
                if (i <= j)
                {
                    Problema temp = NuevaLista[i];
                    NuevaLista[i] = NuevaLista[j];
                    NuevaLista[j] = temp;
                    i++;
                    j--;
                }
            }
            if (inicio < j)
            {
                quicksortTiempo(ref NuevaLista, inicio, j);
            }
            if (i < fin)
            {
                quicksortTiempo(ref NuevaLista, i, fin);
            }
        }
    }
}
