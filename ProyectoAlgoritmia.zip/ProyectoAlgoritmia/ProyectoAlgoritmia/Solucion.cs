﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoAlgoritmia
{
    public class Solucion
    {
        public string solucion, origen, destino;
        public int ponderacion; 
        public Solucion(string solucion, int ponderacion, string origen, string destino)
        {
            this.solucion = solucion;
            this.ponderacion = ponderacion;
            this.origen = origen;
            this.destino = destino; 
        }
    }
}
