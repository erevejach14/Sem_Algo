﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoAlgoritmia
{
    public class Nodo
    {
        public string nombre;
        public int x, y;
        public Nodo (string nombre, int x,int y )
        {
            this.nombre = nombre;
            this.x = x;
            this.y = y; 
        }
    }
}
