﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoAlgoritmia
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            ListaProblemas listaProblemas = new ListaProblemas();
            ListaSoluciones listaSoluciones = new ListaSoluciones();

            Problema problema1 = new Problema("Violación menor de la ley",11,"A","B");
            Problema problema2 = new Problema("Muerte de cónguye", 100, "C", "B");
            Problema problema3 = new Problema("Divorcio",73, "C", "B");
            Problema problema4 = new Problema("Separación marital",65, "D", "B");
            Problema problema5 = new Problema("Tiempo en prisión",63, "E", "A");
            Problema problema6 = new Problema("Muerte de un miembro de la familia",63, "A", "E");
            Problema problema7 = new Problema("Enfermedad / Lesiones personales",53, "D", "C");
            Problema problema8 = new Problema(" Matrimonio",50, "A", "D");
            Problema problema9 = new Problema("Despedido del trabajo",47, "E", "A");
            Problema problema10 = new Problema("Reconciliación del matrimonio",45, "D", "E");
            Problema problema11 = new Problema("Juvilación",45, "E", "B");
            Problema problema12 = new Problema("Cambio de salud de un miebro de la familia",44, "E", "C");
          /* Problema problema13 = new Problema("Embarazo",40);
            Problema problema14 = new Problema("Dificultades en el sexo",39);
            Problema problema15 = new Problema("Aumento de miembros en la familia", 39);
            Problema problema16 = new Problema("Ajustes en el negocio",39);
            Problema problema17 = new Problema("Cambio del estatus financiero",38);
            Problema problema18 = new Problema("Muerte de un buen amigo",37);
            Problema problema19 = new Problema("Cambio en el numero de discuciones en el matrimonio",35);
            Problema problema20 = new Problema("Hipóteca / Préstamo más de $10,000",31);
            Problema problema21 = new Problema("Exclusión de la hipoteca/ prestamo",30);
            Problema problema22 = new Problema("Cambio en responsabilidades del trabajo",29);
            Problema problema23 = new Problema("Hijo(a) se fue de la casa",29);
            Problema problema24 = new Problema("Problemas con los suegros",29);
            Problema problema25 = new Problema("Logros excepcionales",28);
            Problema problema26 = new Problema("El cónyufe comenzo a trabajar",26);
            Problema problema27 = new Problema("Terminar o empezar la escuela",26);
            Problema problema28 = new Problema("Cambio de condiciones de vida",25);
            Problema problema29 = new Problema("Consciente de malos hábitos",24);
            Problema problema30 = new Problema("Problemas con el jefe",23);
            Problema problema31 = new Problema("Cambio en las horas/ condiciones de trabajo",20);
            Problema problema32 = new Problema("Cambio de residencia",20);
            Problema problema33 = new Problema("Cambio de la escuela",20);
            Problema problema34 = new Problema("Cambio de hábitos recreativos",19);
            Problema problema35 = new Problema("Cambio en actividades religiosas",19);
            Problema problema36 = new Problema("Cambio en actividades sociales",18);
            Problema problema37 = new Problema("Prestamo menor a $10,000",18);
            Problema problema38 = new Problema("Cambio en hábitos de dormir",16);
            Problema problema39 = new Problema("Cambio en el numero de reuniones familiares",15);
            Problema problema40 = new Problema("Cambio en hábitos alimenticios",15);
            Problema problema41 = new Problema("Vacaciones",13);
            Problema problema42 = new Problema("Celebración de navidad",12);*/

            listaProblemas.Add(problema1);
            listaProblemas.Add(problema2);
            listaProblemas.Add(problema3);
            listaProblemas.Add(problema4);
            listaProblemas.Add(problema5);
            listaProblemas.Add(problema6);
            listaProblemas.Add(problema7);
            listaProblemas.Add(problema8);
            listaProblemas.Add(problema9);
            listaProblemas.Add(problema10);
            listaProblemas.Add(problema11);
            listaProblemas.Add(problema12);
          /*  listaProblemas.Add(problema13);
            listaProblemas.Add(problema14);
            listaProblemas.Add(problema15);
            listaProblemas.Add(problema16);
            listaProblemas.Add(problema17);
            listaProblemas.Add(problema18);
            listaProblemas.Add(problema19);
            listaProblemas.Add(problema20);
            listaProblemas.Add(problema21);
            listaProblemas.Add(problema22);
            listaProblemas.Add(problema23);
            listaProblemas.Add(problema24);
            listaProblemas.Add(problema25);
            listaProblemas.Add(problema26);
            listaProblemas.Add(problema27);
            listaProblemas.Add(problema28);
            listaProblemas.Add(problema29);
            listaProblemas.Add(problema30);
            listaProblemas.Add(problema31);
            listaProblemas.Add(problema32);
            listaProblemas.Add(problema33);
            listaProblemas.Add(problema34);
            listaProblemas.Add(problema35);
            listaProblemas.Add(problema36);
            listaProblemas.Add(problema37);
            listaProblemas.Add(problema38);
            listaProblemas.Add(problema39);
            listaProblemas.Add(problema40);
            listaProblemas.Add(problema41);
            listaProblemas.Add(problema42);*/

            Solucion solucion1 = new Solucion("Dormir", 20,"A","B" );
            Solucion solucion2 = new Solucion("Ir al psicologo", 30,"C", "B");
            Solucion solucion3 = new Solucion("Tomar una aspirina", 10,"A", "D");
            Solucion solucion4 = new Solucion("Escuchar musica", 15,"A", "C");
            Solucion solucion5 = new Solucion("Salir con amigos", 40, "D", "B");
            Solucion solucion6 = new Solucion("Hablar con alguien", 25, "E", "B");
            Solucion solucion7 = new Solucion("Ir al spa", 30, "A", "E");
            Solucion solucion8 = new Solucion("Viajar", 50, "B", "E");
            Solucion solucion9 = new Solucion("Hacer nuevos amigos", 22, "F", "B");
            Solucion solucion10 = new Solucion("Hacer deporte", 25, "A", "F");
            Solucion solucion11 = new Solucion("Cambiar de trabajo", 20,"F", "C");
            Solucion solucion12 = new Solucion("Comer dulces", 10, "E", "G");
            Solucion solucion13 = new Solucion("Salir a pasear", 25, "G", "A");

            listaSoluciones.Add(solucion1);
            listaSoluciones.Add(solucion2);
            listaSoluciones.Add(solucion3);
            listaSoluciones.Add(solucion4);
            listaSoluciones.Add(solucion5);
            listaSoluciones.Add(solucion6);
            listaSoluciones.Add(solucion7);
            listaSoluciones.Add(solucion8);
            listaSoluciones.Add(solucion9);
            listaSoluciones.Add(solucion10);
            listaSoluciones.Add(solucion11);
            listaSoluciones.Add(solucion12);
            listaSoluciones.Add(solucion13);





            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Formulario ventana = new Formulario(ref listaProblemas, ref listaSoluciones);
            ventana.ShowDialog();

            //Application.Run(new Formulario());
        }
    }
}
