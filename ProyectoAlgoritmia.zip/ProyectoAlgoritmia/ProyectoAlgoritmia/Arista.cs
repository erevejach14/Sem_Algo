﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Drawing; 
using System.Text;
using System.Threading.Tasks;

namespace ProyectoAlgoritmia
{
    public class Arista
    {
        public string destino;
        public int ponderacion; 
        public Point coordenada;
        public Arista(string destino, int ponderacion)
        {
            this.destino = destino;
            this.ponderacion = ponderacion; 
        }
    }
}
