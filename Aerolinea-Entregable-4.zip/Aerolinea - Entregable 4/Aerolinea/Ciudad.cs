﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aerolinea
{
   public class Ciudad
    {
        public char nombre;
        public int x, y;
        public Ciudad(char nombre, int x, int y)
        {
            this.nombre = nombre;
            this.x = x;
            this.y = y; 

        }
    }
}
