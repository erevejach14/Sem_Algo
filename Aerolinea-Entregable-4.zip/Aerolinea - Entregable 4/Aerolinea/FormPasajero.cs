﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aerolinea
{
    public partial class FormPasajero : Form
    {
        string pasajero; 

        ClaseListaPasajeros ListaPasajeros = new ClaseListaPasajeros();
        ClaseListaVuelos NuevaLista = new ClaseListaVuelos();        

        public FormPasajero(ref ClaseListaPasajeros ListaPasajeros, ref ClaseListaVuelos NuevaLista)
        {
            this.ListaPasajeros = ListaPasajeros;
            this.NuevaLista = NuevaLista;
            
            InitializeComponent();

            actualizaLista();
            buttonEliminar.Enabled = false; 
        }

        private void actualizaLista()
        {
            for (int i = 0; i < NuevaLista.Count; i++)
            {
                for (int j = 0; j < NuevaLista[i].ListaPasajeros.Count; j++)
                {
                    string[] s = new string[5];
                    s[0] = i.ToString();
                    s[1] = j.ToString();
                    s[2] = NuevaLista[i].getRuta();
                    s[3] = NuevaLista[i].getPasajero(j).getNombre();
                    s[4] = NuevaLista[i].getPasajero(j).getAsiento();
                    ListViewItem itm = new ListViewItem(s);
                    listViewPasajero.Items.Add(itm);

                }
            }
        }

        private void buttonEliminar_Click(object sender, EventArgs e)
        {
            Console.WriteLine(listViewPasajero.FocusedItem.Text);
            Console.WriteLine(listViewPasajero.FocusedItem.SubItems[1].Text);


            int indiceVuelo = Int32.Parse(listViewPasajero.FocusedItem.Text);
            int indicePasajero = Int32.Parse(listViewPasajero.FocusedItem.SubItems[1].Text);


            NuevaLista[indiceVuelo].validarAsiento[Int32.Parse(NuevaLista[indiceVuelo].getPasajero(indicePasajero).getAsiento()) - 1] = true;
            NuevaLista[indiceVuelo].asientosDisp++;

            NuevaLista[indiceVuelo].ListaPasajeros.Remove(NuevaLista[indiceVuelo].ListaPasajeros[indicePasajero]);
            listViewPasajero.Items.Clear();
            actualizaLista();
        }

        private void listViewPasajero_SelectedIndexChanged(object sender, EventArgs e)
        {
            buttonEliminar.Enabled = true;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            pasajero = textBox1.Text;
            listViewPasajero.Items.Clear();
            for (int i = 0; i < NuevaLista.Count; i++)
            {
                for (int k=0; k<NuevaLista[i].ListaPasajeros.Count; k++)
                {
                    if (NuevaLista[i].ListaPasajeros[k].nombre.Contains(pasajero))
                    {
                        string[] s = new string[5];
                        s[0] = i.ToString();
                        s[1] = k.ToString();
                        s[2] = NuevaLista[i].getRuta();
                        s[3] = NuevaLista[i].getPasajero(k).getNombre();
                        s[4] = NuevaLista[i].getPasajero(k).getAsiento();
                        ListViewItem itm = new ListViewItem(s);
                        listViewPasajero.Items.Add(itm);
                    }
                }
            }
        }

        private void FormPasajero_Load(object sender, EventArgs e)
        {
     /*       for (int i = 0; i < NuevaLista.Count; i++)
            {
                for (int k = 0; k < NuevaLista[i].ListaPasajeros.Count; k++)
                {
                        ListViewItem lista = new ListViewItem(NuevaLista[i].ListaPasajeros[k].getVuelo());
                        lista.SubItems.Add(NuevaLista[i].ListaPasajeros[k].nombre);
                        lista.SubItems.Add(NuevaLista[i].ListaPasajeros[k].asiento.ToString());
                        listViewPasajero.Items.Add(lista);
                }
            }*/
        }
    }
}
