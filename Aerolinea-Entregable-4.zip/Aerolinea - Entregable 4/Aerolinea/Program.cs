﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Aerolinea
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            ClaseListaVuelos NuevaLista = new ClaseListaVuelos();
            ClaseListaPasajeros ListaPasajeros = new ClaseListaPasajeros();
            ListaCiudades listaCiudades = new ListaCiudades();

          /*  ClaseVuelos vuelo1 = new ClaseVuelos("SK1AB", 'A', 'B',800,50,Convert.ToDateTime("12/22/2016 12:39:00 "), 16);
            ClaseVuelos vuelo2 = new ClaseVuelos("SK1AF", 'A', 'F',1050,90, Convert.ToDateTime("12/12/2015 05:24:00 "), 16);
            ClaseVuelos vuelo3 = new ClaseVuelos("SK1AG", 'A', 'G',1150,80, Convert.ToDateTime("03/03/1996 07:39:00 "), 16);
            ClaseVuelos vuelo4 = new ClaseVuelos("SK1BA", 'B', 'A',600,50, Convert.ToDateTime("12/12/2017 05:24:00 "), 16);
            ClaseVuelos vuelo5 = new ClaseVuelos("SK1BC", 'B', 'C',750,40, Convert.ToDateTime("06/05/2015 22:00:00 "), 16);
            ClaseVuelos vuelo6 = new ClaseVuelos("SK1BD", 'B', 'D',650,60, Convert.ToDateTime("02/09/2016 1:24:00 "), 16);
            ClaseVuelos vuelo7 = new ClaseVuelos("SK1BE", 'B', 'E',1850,70, Convert.ToDateTime("11/02/2018 05:24:00 "), 16);
            ClaseVuelos vuelo8 = new ClaseVuelos("SK1CB", 'C', 'B',800,35, Convert.ToDateTime("10/01/2019 10:24:00 "), 16);
            ClaseVuelos vuelo9 = new ClaseVuelos("SK1CE", 'C', 'E',850,50, Convert.ToDateTime("11/11/2010 11:24:00 "), 16);
            ClaseVuelos vuelo10 = new ClaseVuelos("SK1EC", 'E', 'C',750,45, Convert.ToDateTime("09/12/2011 08:24:00 "), 16);
            ClaseVuelos vuelo11 = new ClaseVuelos("SK1EG", 'E', 'G',1150,80, Convert.ToDateTime("05/11/2011 05:24:00 "), 16);
            ClaseVuelos vuelo12 = new ClaseVuelos("SK1EL", 'E', 'L',1650,60, Convert.ToDateTime("07/10/2015 04:24:00 "), 16);
            ClaseVuelos vuelo13 = new ClaseVuelos("SK1ED", 'E', 'D',700,35, Convert.ToDateTime("04/09/2018 02:24:00 "), 16);
            ClaseVuelos vuelo14 = new ClaseVuelos("SK1DE", 'D', 'E',900,45, Convert.ToDateTime("03/08/2019 03:24:00 "), 16);
            ClaseVuelos vuelo15 = new ClaseVuelos("SK1DB", 'D', 'B',700,55, Convert.ToDateTime("02/04/1900 01:39:00 "), 16);
            ClaseVuelos vuelo16 = new ClaseVuelos("SK1FB", 'F', 'B',800,65, Convert.ToDateTime("01/12/2011 12:24:00 "), 16);
            ClaseVuelos vuelo17 = new ClaseVuelos("SK1FL", 'F', 'L',2850,140, Convert.ToDateTime("02/02/2012 11:24:00 "), 16);
            ClaseVuelos vuelo18 = new ClaseVuelos("SK1GA", 'G', 'A',1250,95, Convert.ToDateTime("03/09/2013 10:24:00 "), 16);
            ClaseVuelos vuelo19 = new ClaseVuelos("SK1GE", 'G', 'E',1175,75, Convert.ToDateTime("04/12/2014 09:24:00 "), 16);
            ClaseVuelos vuelo20 = new ClaseVuelos("SK1GL", 'G', 'L',2675,135, Convert.ToDateTime("05/02/2015 08:24:00 "), 16);
            ClaseVuelos vuelo21 = new ClaseVuelos("SK1GJ", 'G', 'J',1400,60, Convert.ToDateTime("06/01/2016 07:24:00 "), 16);
            ClaseVuelos vuelo22 = new ClaseVuelos("SK1GH", 'G', 'H',450,25, Convert.ToDateTime("07/04/2017 06:24:00 "), 16);
            ClaseVuelos vuelo23 = new ClaseVuelos("SK1HG", 'H', 'G',350,30, Convert.ToDateTime("08/07/2017 05:24:00 "), 16);
            ClaseVuelos vuelo24 = new ClaseVuelos("SK1HI", 'H', 'I',400,35, Convert.ToDateTime("09/08/2017 14:24:00 "), 16);
            ClaseVuelos vuelo25 = new ClaseVuelos("SK1IH", 'I', 'H',400,30, Convert.ToDateTime("10/04/2018 03:24:00 "), 16);
            ClaseVuelos vuelo26 = new ClaseVuelos("SK1IK", 'I', 'K',400,35, Convert.ToDateTime("11/03/2018 02:24:00 "), 16);
            ClaseVuelos vuelo27 = new ClaseVuelos("SK1KI", 'K', 'I',400,35, Convert.ToDateTime("12/11/2018 21:24:00 "), 16);
            ClaseVuelos vuelo28 = new ClaseVuelos("SK1KJ", 'K', 'J',300,25, Convert.ToDateTime("01/10/2018 12:24:00 "), 16);
            ClaseVuelos vuelo29 = new ClaseVuelos("SK1JL", 'J', 'L',750,40, Convert.ToDateTime("02/07/2019 11:24:00 "), 16);
            ClaseVuelos vuelo30 = new ClaseVuelos("SK1JM", 'J', 'M',1450,70, Convert.ToDateTime("03/02/1816 10:24:00 "), 16);
            ClaseVuelos vuelo31 = new ClaseVuelos("SK1LM", 'L', 'M',650,40, Convert.ToDateTime("04/08/1016 09:24:00 "), 16);
            ClaseVuelos vuelo32 = new ClaseVuelos("SK1LK", 'L', 'K',700,70, Convert.ToDateTime("05/07/1996 08:24:00 "), 16);
            ClaseVuelos vuelo33 = new ClaseVuelos("SK1LE", 'L', 'E',1550,60, Convert.ToDateTime("06/03/1997 17:24:00 "), 16);
            ClaseVuelos vuelo34 = new ClaseVuelos("SK1ML", 'M', 'L',700,40, Convert.ToDateTime("07/04/1998 15:24:00 "), 16);

            NuevaLista.Add(vuelo1);
            NuevaLista.Add(vuelo2);
            NuevaLista.Add(vuelo3);
            NuevaLista.Add(vuelo4);
            NuevaLista.Add(vuelo5);
            NuevaLista.Add(vuelo6);
            NuevaLista.Add(vuelo7);
            NuevaLista.Add(vuelo8);
            NuevaLista.Add(vuelo9);
            NuevaLista.Add(vuelo10);
            NuevaLista.Add(vuelo11);
            NuevaLista.Add(vuelo12);
            NuevaLista.Add(vuelo13);
            NuevaLista.Add(vuelo14);
            NuevaLista.Add(vuelo15);
            NuevaLista.Add(vuelo16);
            NuevaLista.Add(vuelo17);
            NuevaLista.Add(vuelo18);
            NuevaLista.Add(vuelo19);
            NuevaLista.Add(vuelo20);
            NuevaLista.Add(vuelo21);
            NuevaLista.Add(vuelo22);
            NuevaLista.Add(vuelo23);
            NuevaLista.Add(vuelo24);
            NuevaLista.Add(vuelo25);
            NuevaLista.Add(vuelo26);
            NuevaLista.Add(vuelo27);
            NuevaLista.Add(vuelo28);
            NuevaLista.Add(vuelo29);
            NuevaLista.Add(vuelo30);
            NuevaLista.Add(vuelo31);
            NuevaLista.Add(vuelo32);
            NuevaLista.Add(vuelo33);
            NuevaLista.Add(vuelo34);*/
            //Leer vuelos
            if (File.Exists("Vuelos.txt"))
            {
                StreamReader readerVuelos = new StreamReader("Vuelos.txt");

                char origen, destino; 
                string ruta;
                int asientosDisp, costo, duracion, o;
                DateTime fecha;
                string leer = readerVuelos.ReadLine();
                bool[] validarAsiento = new bool[16];
                string[] formatoVuelos; 
                
                while (leer!=null)
                {
                    formatoVuelos = leer.Split('|');
                    ruta = formatoVuelos[0];
                    origen = Convert.ToChar(formatoVuelos[1]);
                    destino = Convert.ToChar(formatoVuelos[2]);
                    asientosDisp = Int32.Parse(formatoVuelos[3]);
                    costo = Int32.Parse(formatoVuelos[4]);
                    duracion = Int32.Parse(formatoVuelos[5]);
                    fecha = Convert.ToDateTime(formatoVuelos[6]);
                    o = 7; 
                    for (int i=0; i<16; i++)
                    {
                        validarAsiento[i] = Convert.ToBoolean(formatoVuelos[o]);
                        o++; 
                    }

                    ClaseVuelos vuelo = new ClaseVuelos(ruta, origen, destino, costo, duracion, fecha, asientosDisp, validarAsiento);
                    NuevaLista.Add(vuelo);
                    leer = readerVuelos.ReadLine();
                }
                readerVuelos.Close();
            }

            //Leer pasajeros 
            if (File.Exists("Pasajero.txt"))
            {
                StreamReader readerPasajeros = new StreamReader("Pasajero.txt");

                string nombre, apellido, vuelo, asiento, edad;
                string[] formatoPasajeros;

                string leerr = readerPasajeros.ReadLine();

                while (leerr!=null)
                {
                    formatoPasajeros = leerr.Split('|');
                    nombre = formatoPasajeros[0];
                    apellido = formatoPasajeros[1];
                    asiento = formatoPasajeros[2];
                    edad = formatoPasajeros[3];
                    vuelo = formatoPasajeros[4];

                    ClasePasajero pasajero = new ClasePasajero(nombre, apellido, edad, asiento, vuelo);

                    for (int i=0; i<NuevaLista.Count; i++)
                    {
                        if(vuelo==NuevaLista[i].ruta)
                        {
                            NuevaLista[i].setPasajero(pasajero);
                            NuevaLista[i].validarAsiento[Int32.Parse(asiento) - 1] = false;
                            break; 
                        }
                   
                    }
                    leerr = readerPasajeros.ReadLine();
                }
                readerPasajeros.Close();
            }
            //Leer ciudades
            if (File.Exists("Ciudades.txt"))
            {
                StreamReader readerCiudades = new StreamReader("Ciudades.txt");
                char nombre;
                int x, y;
                string[] formatoCiudades;

                string leerrr = readerCiudades.ReadLine();
                while (leerrr!=null)
                {
                    formatoCiudades = leerrr.Split('|');
                    nombre = Convert.ToChar(formatoCiudades[0]);
                    x = Int32.Parse(formatoCiudades[1]);
                    y = Int32.Parse(formatoCiudades[2]);

                    Ciudad ciudad = new Ciudad(nombre, x, y);
                    listaCiudades.Add(ciudad); 

                    leerrr = readerCiudades.ReadLine();
                }
                readerCiudades.Close();
            }



            Grafo grafo = new Grafo(NuevaLista, listaCiudades);

            for (int i=0; i<grafo.Count; i++)
            {
                System.Console.WriteLine(grafo[i]);
            }
            

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            FormPrincipal ventanaPrincipal = new FormPrincipal(ref NuevaLista, ref ListaPasajeros, ref listaCiudades);   
            ventanaPrincipal.ShowDialog();

        }
    }
}
