﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO; 

namespace Aerolinea
{
    public partial class FormPrincipal : Form
    {
       

        ClaseListaVuelos NuevaLista = new ClaseListaVuelos();
        ClaseListaPasajeros ListaPasajeros = new ClaseListaPasajeros();
        ListaCiudades listaCiudades = new ListaCiudades();

        public FormPrincipal(ref ClaseListaVuelos NuevaLista, ref ClaseListaPasajeros ListaPasajeros, ref ListaCiudades listaCiudades)
        {
            this.NuevaLista = NuevaLista;
            this.ListaPasajeros = ListaPasajeros;
            this.listaCiudades = listaCiudades; 
            InitializeComponent();
        }

        private void botonVuelos_Click(object sender, EventArgs e)
        {
            Vuelos ventanaVuelos = new Vuelos(ref NuevaLista, ref ListaPasajeros, ref listaCiudades);
            ventanaVuelos.ShowDialog();
        }

        private void botonPasajeros_Click(object sender, EventArgs e)
        {
            FormPasajero ventanaPasajeros = new FormPasajero(ref ListaPasajeros, ref NuevaLista);
            ventanaPasajeros.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormVuelos ventanaVuelos = new FormVuelos(ref NuevaLista, ref ListaPasajeros);
            ventanaVuelos.ShowDialog();
        }

        private void FormPrincipal_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (File.Exists("Vuelos.txt"))
            {
                File.Delete("Vuelos.txt");
            }

            if (File.Exists("Pasajero.txt"))
            {
                File.Delete("Pasajero.txt"); 
            }
            
            if (File.Exists("Ciudades.txt"))
            {
                File.Delete("Ciudades.txt");
            }

            StreamWriter writerVuelos = new StreamWriter("Vuelos.txt");
            StreamWriter writerPasajeros = new StreamWriter("Pasajero.txt"); 
            StreamWriter writerCiudades = new StreamWriter("Ciudades.txt"); 
            //For para escribir vuelos dentro de archivo. 
            for (int i=0; i<NuevaLista.Count; i++)
            {
                string vuelo = NuevaLista[i].ruta + "|" + NuevaLista[i].origen + "|" + NuevaLista[i].destino + "|" +
                               NuevaLista[i].asientosDisp + "|" + NuevaLista[i].costo + "|" + NuevaLista[i].duracion + "|" +
                               NuevaLista[i].fecha + "|" + NuevaLista[i].validarAsiento[0] + "|" + NuevaLista[i].validarAsiento[1] + "|" +
                               NuevaLista[i].validarAsiento[2] + "|" + NuevaLista[i].validarAsiento[3] + "|" + NuevaLista[i].validarAsiento[4] + "|" +
                               NuevaLista[i].validarAsiento[5] + "|" + NuevaLista[i].validarAsiento[6] + "|" + NuevaLista[i].validarAsiento[7] + "|" +
                               NuevaLista[i].validarAsiento[8] + "|" + NuevaLista[i].validarAsiento[9] + "|" + NuevaLista[i].validarAsiento[10] + "|" +
                               NuevaLista[i].validarAsiento[11] + "|" + NuevaLista[i].validarAsiento[12] + "|" + NuevaLista[i].validarAsiento[13] + "|" +
                               NuevaLista[i].validarAsiento[14] + "|" + NuevaLista[i].validarAsiento[15];

                writerVuelos.WriteLine(vuelo);
                writerVuelos.Flush();
            }
            writerVuelos.Close();
            //For para escribir pasajeros en archivo 
            for (int i=0; i <NuevaLista.Count; i++)
            {
                for (int j=0; j<NuevaLista[i].ListaPasajeros.Count; j++)
                {
                    string pasajero = NuevaLista[i].ListaPasajeros[j].nombre + "|" + NuevaLista[i].ListaPasajeros[j].apellido + "|" + 
                                      NuevaLista[i].ListaPasajeros[j].getAsiento() + "|" + NuevaLista[i].ListaPasajeros[j].getEdad() + "|" + 
                                      NuevaLista[i].ListaPasajeros[j].getVuelo();

                    writerPasajeros.WriteLine(pasajero);
                    writerPasajeros.Flush();
                }
               
            }
            writerPasajeros.Close();

            for (int i=0; i<listaCiudades.Count; i++)
            {
                string ciudad = listaCiudades[i].nombre.ToString() + "|" + listaCiudades[i].x.ToString() + "|" + listaCiudades[i].y.ToString();
                writerCiudades.WriteLine(ciudad);
                writerCiudades.Flush();
            }
            writerCiudades.Close();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Ciudades ventana = new Ciudades(ref listaCiudades, ref NuevaLista);
            ventana.ShowDialog();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            FormPorUsuario ventana = new FormPorUsuario();
            ventana.ShowDialog();
        }
    }
}
