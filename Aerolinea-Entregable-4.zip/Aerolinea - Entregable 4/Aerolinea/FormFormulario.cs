﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aerolinea
{
    public partial class FormFormulario : Form
    {
        int indice;
        string nombre, asiento, edad, apellido, ruta;
        //string asiento; 

        ClaseListaVuelos NuevaLista = new ClaseListaVuelos();
        ClaseListaPasajeros ListaPasajeros = new ClaseListaPasajeros();
         
        public FormFormulario(ref ClaseListaVuelos NuevaLista, ref ClaseListaPasajeros ListaPasajeros, int indice)
        {
            this.indice = indice; 
            this.NuevaLista = NuevaLista;
            this.ListaPasajeros = ListaPasajeros;
            InitializeComponent();
            
        }

        private void botonAsiento_Click(object sender, EventArgs e)
        {
            nombre = textBox1.Text;
            apellido = textBox2.Text;
            edad = textBox3.Text;
            ruta = NuevaLista[indice].getRuta();

            FormAsientos ventanaMostrarAsientos = new FormAsientos(ref NuevaLista,ref ListaPasajeros, indice);
            
            ventanaMostrarAsientos.ShowDialog();
            asiento = ventanaMostrarAsientos.getAsiento();
        }

        private void FormFormulario_Load(object sender, EventArgs e)
        {
           
            
        }

        private void button1_Click(object sender, EventArgs e)
        {

            NuevaLista[indice].validarAsiento[Int32.Parse(asiento)-1] = false;
            NuevaLista[indice].asientosDisp--;
            ClasePasajero Pasajero = new ClasePasajero(nombre, apellido, edad.ToString(), asiento, ruta);
            NuevaLista[indice].setPasajero(Pasajero); 
            this.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                botonAsiento.Enabled = false;
            }
            else if (textBox2.Text == "")
            {
                botonAsiento.Enabled = false;
            }
            else if (textBox3.Text == "")
            {
                botonAsiento.Enabled = false;
            }
            else
            {
                botonAsiento.Enabled = true;

            }
            
            
        }


        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                botonAsiento.Enabled = false;
            }
            else if (textBox2.Text == "")
            {
                botonAsiento.Enabled = false;
            }
            else if (textBox3.Text == "")
            {
                botonAsiento.Enabled = false;
            }
            else
            {
                botonAsiento.Enabled = true;
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                botonAsiento.Enabled = false;
            }
            else if (textBox2.Text == "")
            {
                botonAsiento.Enabled = false;
            }
            else if (textBox3.Text == "")
            {
                botonAsiento.Enabled = false;
            }
            else
            {
                botonAsiento.Enabled = true;
            }
        }
    }
}
