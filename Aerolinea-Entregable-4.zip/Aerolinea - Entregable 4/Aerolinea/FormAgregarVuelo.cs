﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aerolinea
{
    public partial class FormAgregarVuelo : Form
    {

        ClaseListaVuelos NuevaLista = new ClaseListaVuelos();
        ListaCiudades listaCiudades = new ListaCiudades(); 

        bool rutaValida = true;
        bool existeOrigen = true;
        bool existeDestino = true; 

        public FormAgregarVuelo(ref ClaseListaVuelos NuevaLista, ref ListaCiudades listaCiudades)
        {
            this.NuevaLista = NuevaLista;
            this.listaCiudades = listaCiudades; 
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text==" " || textBox2.Text == " " || textBox3.Text == ""  || textBox5.Text == "")
            {
                buttonAgregar.Enabled = false; 
            }
            else
            {
                buttonAgregar.Enabled = true; 
            }

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text == " " || textBox2.Text == " " || textBox3.Text == ""  || textBox5.Text == "")
            {
                buttonAgregar.Enabled = false;
            }
            else
            {
                buttonAgregar.Enabled = true;
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text == " " || textBox2.Text == " " || textBox3.Text == ""  || textBox5.Text == "")
            {
                buttonAgregar.Enabled = false;
            }
            else
            {
                buttonAgregar.Enabled = true;
            }
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text == " " || textBox2.Text == " " || textBox3.Text == ""  || textBox5.Text == "")
            {
                buttonAgregar.Enabled = false;
            }
            else
            {
                buttonAgregar.Enabled = true;
            }
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text == " " || textBox2.Text == " " || textBox3.Text == ""  || textBox5.Text == "")
            {
                buttonAgregar.Enabled = false;
            }
            else
            {
                buttonAgregar.Enabled = true;
            }
        }

        private void buttonAgregar_Click(object sender, EventArgs e)
        {
            char origen = Convert.ToChar(textBox1.Text);
            char destino = Convert.ToChar(textBox2.Text);
            string ruta = "SK1" + textBox1.Text + textBox2.Text;
            int costo = Int32.Parse(textBox3.Text);
            int duracion = Int32.Parse(textBox3.Text);
            int asientos = 16;
            bool[] validarAsientos = new bool[16];

            


            for (int i=0; i<NuevaLista.Count; i++)
            {
                
                if (ruta == NuevaLista[i].ruta || origen == destino)
                {
                    MessageBox.Show("Esa ruta ya existe, o el origen y el destino es el mismo.  ^^");
                    rutaValida = false;
                    break;        
                }
                else
                {
                    rutaValida = true;                    
                }
            }

            for (int y = 0; y <listaCiudades.Count; y++)
            {
                if (origen == listaCiudades[y].nombre/*NuevaLista[y].origen || origen == NuevaLista[y].destino*/)
                {
                    existeOrigen = true;
                    break; 
                }
                else
                {
                    existeOrigen = false;
                }
            }

            for (int y = 0; y < listaCiudades.Count; y++)
            {
                if (destino == listaCiudades[y].nombre)
                {
                    existeDestino = true;
                    break;
                }
                else
                {
                    existeDestino = false;
                }
            }



            if (existeDestino == false && existeOrigen == false)
            {
                if (MessageBox.Show("El origen y el destino no existen, ¿Desea agregarlos al mapa?  ^^", "", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    Ciudades ventana = new Ciudades(ref listaCiudades, ref NuevaLista);
                    ventana.ShowDialog();
                    ventana.ShowDialog();
                    rutaValida = true;
                }
                else
                {
                    rutaValida = false; 
                }
            }
            else if (existeOrigen==false)
            {
                if (MessageBox.Show("El origen no existe, ¿Desea agregarlo al mapa?  ^^", "", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    Ciudades ventana = new Ciudades(ref listaCiudades, ref NuevaLista);
                    ventana.ShowDialog();
                    rutaValida = true;
                }
                else
                {
                    rutaValida = false; 
                }
            }
            else if (existeDestino==false)
            {
                if (MessageBox.Show("El destino no existe, ¿Desea agregarlo al mapa?  ^^", "", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    Ciudades ventana = new Ciudades(ref listaCiudades, ref NuevaLista);
                    ventana.ShowDialog();
                    rutaValida = true;
                }
                else
                {
                    rutaValida = false;
                }
            }


            if (rutaValida ==true)
            {
                for (int k = 0; k<16; k++)
                {
                    validarAsientos[k] = true; 
                }
                DateTime fecha = Convert.ToDateTime(dateTimePicker1.Text);
                ClaseVuelos vuelo = new ClaseVuelos(ruta, origen, destino, costo, duracion, fecha, asientos, validarAsientos);
                NuevaLista.Add(vuelo);
                MessageBox.Show("¡Vuelo agregado! ^^");


                this.Close();
            }
            else
            {
                MessageBox.Show("Coloca datos correctos para agregar el vuelo.  ^^");
            }

        }
    }
}
