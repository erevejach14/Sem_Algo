﻿namespace Aerolinea
{
    partial class Vuelos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Vuelos));
            this.botonComprar = new System.Windows.Forms.Button();
            this.listBoxVuelos = new System.Windows.Forms.ListBox();
            this.buttonAgregar = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // botonComprar
            // 
            this.botonComprar.Enabled = false;
            this.botonComprar.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botonComprar.ForeColor = System.Drawing.Color.DarkMagenta;
            this.botonComprar.Location = new System.Drawing.Point(328, 12);
            this.botonComprar.Name = "botonComprar";
            this.botonComprar.Size = new System.Drawing.Size(143, 32);
            this.botonComprar.TabIndex = 0;
            this.botonComprar.Text = "Comprar boleto";
            this.botonComprar.UseVisualStyleBackColor = true;
            this.botonComprar.Click += new System.EventHandler(this.botonComprar_Click);
            // 
            // listBoxVuelos
            // 
            this.listBoxVuelos.Font = new System.Drawing.Font("Futura Bk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBoxVuelos.FormattingEnabled = true;
            this.listBoxVuelos.ItemHeight = 16;
            this.listBoxVuelos.Location = new System.Drawing.Point(12, 12);
            this.listBoxVuelos.Name = "listBoxVuelos";
            this.listBoxVuelos.Size = new System.Drawing.Size(298, 260);
            this.listBoxVuelos.TabIndex = 1;
            this.listBoxVuelos.SelectedIndexChanged += new System.EventHandler(this.listBoxVuelos_SelectedIndexChanged);
            // 
            // buttonAgregar
            // 
            this.buttonAgregar.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAgregar.ForeColor = System.Drawing.Color.DarkMagenta;
            this.buttonAgregar.Location = new System.Drawing.Point(328, 50);
            this.buttonAgregar.Name = "buttonAgregar";
            this.buttonAgregar.Size = new System.Drawing.Size(143, 32);
            this.buttonAgregar.TabIndex = 5;
            this.buttonAgregar.Text = "Agregar Vuelo";
            this.buttonAgregar.UseVisualStyleBackColor = true;
            this.buttonAgregar.Click += new System.EventHandler(this.buttonAgregar_Click);
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.DarkMagenta;
            this.button3.Location = new System.Drawing.Point(328, 88);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(143, 31);
            this.button3.TabIndex = 6;
            this.button3.Text = "Eliminar vuelo";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.DarkMagenta;
            this.button4.Location = new System.Drawing.Point(328, 125);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(143, 32);
            this.button4.TabIndex = 7;
            this.button4.Text = "Actualizar vuelos";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // Vuelos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Pink;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(499, 297);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.buttonAgregar);
            this.Controls.Add(this.listBoxVuelos);
            this.Controls.Add(this.botonComprar);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Vuelos";
            this.RightToLeftLayout = true;
            this.Text = "Selecciona tu vuelo";
            this.Activated += new System.EventHandler(this.Vuelos_Activated);
            this.Load += new System.EventHandler(this.Vuelos_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button botonComprar;
        private System.Windows.Forms.ListBox listBoxVuelos;
        private System.Windows.Forms.Button buttonAgregar;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
    }
}