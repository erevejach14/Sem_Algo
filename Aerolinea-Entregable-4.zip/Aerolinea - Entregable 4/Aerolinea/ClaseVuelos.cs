﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aerolinea
{
    public class ClaseVuelos
    {
        public ClaseListaPasajeros ListaPasajeros = new ClaseListaPasajeros(); 
        public string ruta;
        public char origen, destino;
        public int costo, duracion;
        public DateTime fecha;
        public bool[] validarAsiento = new bool[16];
        public int asientosDisp;
        public int asientos=16;
        public string[] cad;


        public ClaseVuelos(string ruta, char origen, char destino, int costo, int duracion, DateTime fecha, int asientosDisp, bool[] validarAsiento)
        {
            this.ruta = ruta;
            this.origen = origen;
            this.destino = destino;
            this.costo = costo;
            this.duracion = duracion;
            this.fecha = fecha;
            this.asientosDisp = asientosDisp;
            
            for (int i=0; i<16; i++)
            {
                this.validarAsiento[i] = validarAsiento[i];
            }
        }

        public override string ToString()
        {
            return ruta + "   " +asientosDisp.ToString() +"   " + fecha;
        }

        public void setAsiento(int ind)
        {
            asientosDisp--;
            validarAsiento[ind] = false; 
        }

        public bool getAsiento(int ind)
        {
            return validarAsiento[ind];
        }

        public void setPasajero(ClasePasajero pasajero)
        {
            this.ListaPasajeros.Add(pasajero); 
        }

        public string getRuta()
        {
            return ruta; 
        }

        public ClasePasajero getPasajero(int ind)
        {
            return ListaPasajeros[ind]; 
        }

        public int getOcupados()
        {
            return ListaPasajeros.Count();
        }



     public ClaseVuelos()
        {
            string indS = "";
            cad[0]=origen.ToString();
            cad[1]= destino.ToString(); 
            for (int i=2; i<cad.Length; i++)
            {
                if (cad[i]!="|")
                {
                    indS += cad[i]; 
                }
                else
                {
                    validarAsiento[Int32.Parse(indS)] = false;
                    indS = " "; 
                }
            }
        }

    }
}
