﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aerolinea
{
    public partial class FormAsientos : Form
    {
        int indice;
        string numAsiento; 

        ClaseListaVuelos NuevaLista = new ClaseListaVuelos();
        ClaseListaPasajeros ListaPasajeros = new ClaseListaPasajeros();

        /*string nombre;
        string vuelo;
        string apellido;
        int edad;*/
        public FormAsientos(ref ClaseListaVuelos NuevaLista,ref ClaseListaPasajeros ListaPasajeros, int indice)
        {
            numAsiento = "-1"; 
            this.indice = indice;
            this.NuevaLista = NuevaLista;
            this.ListaPasajeros = ListaPasajeros; 
            InitializeComponent();
            inicializarBotones();
        }

        public string getAsiento()
        {
            return numAsiento;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            numAsiento = "1";
            getAsiento();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            numAsiento = "2";
            getAsiento();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            numAsiento = "3";
            getAsiento();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            numAsiento = "4";
            getAsiento();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            numAsiento = "5";
            getAsiento();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            numAsiento = "6";
            getAsiento();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            numAsiento = "7";
            getAsiento();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            numAsiento = "8";
            getAsiento();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            numAsiento = "9";
            getAsiento();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            numAsiento = "10";
            getAsiento();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            numAsiento = "11";
            getAsiento();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            numAsiento = "12";
            getAsiento();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            numAsiento = "13";
            getAsiento();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            numAsiento = "14";
            getAsiento();
        }

        private void button15_Click(object sender, EventArgs e)
        {
            numAsiento = "15";
            getAsiento();
        }

        private void button16_Click(object sender, EventArgs e)
        {
            numAsiento = "16";
            getAsiento();
        }

        private void inicializarBotones()
        {
            if (NuevaLista[indice].validarAsiento[0] == true)
            {
                button1.Enabled = true;
                //button1.BackColor = Color.LightBlue; 
            }
            else
            {
                button1.Enabled = false;
                //  button1.BackColor = Color.BlueViolet;
            }
            if (NuevaLista[indice].validarAsiento[1] == true)
            {
                button2.Enabled = true;
                // button1.BackColor = Color.LightBlue;
            }
            else
            {
                button2.Enabled = false;
            }
            if (NuevaLista[indice].validarAsiento[2] == true)
            {
                button3.Enabled = true;
            }
            else
            {
                button3.Enabled = false;
            }
            if (NuevaLista[indice].validarAsiento[3] == true)
            {
                button4.Enabled = true;
            }
            else
            {
                button4.Enabled = false;
            }
            if (NuevaLista[indice].validarAsiento[4] == true)
            {
                button5.Enabled = true;
            }
            else
            {
                button5.Enabled = false;
            }
            if (NuevaLista[indice].validarAsiento[5] == true)
            {
                button6.Enabled = true;
            }
            else
            {
                button6.Enabled = false;
            }
            if (NuevaLista[indice].validarAsiento[6] == true)
            {
                button7.Enabled = true;
            }
            else
            {
                button7.Enabled = false;
            }
            if (NuevaLista[indice].validarAsiento[7] == true)
            {
                button8.Enabled = true;
            }
            else
            {
                button8.Enabled = false;
            }
            if (NuevaLista[indice].validarAsiento[8] == true)
            {
                button9.Enabled = true;
            }
            else
            {
                button9.Enabled = false;
            }
            if (NuevaLista[indice].validarAsiento[9] == true)
            {
                button10.Enabled = true;
            }
            else
            {
                button10.Enabled = false;
            }
            if (NuevaLista[indice].validarAsiento[10] == true)
            {
                button11.Enabled = true;
            }
            else
            {
                button11.Enabled = false;
            }
            if (NuevaLista[indice].validarAsiento[11] == true)
            {
                button12.Enabled = true;
            }
            else
            {
                button12.Enabled = false;
            }
            if (NuevaLista[indice].validarAsiento[12] == true)
            {
                button13.Enabled = true;
            }
            else
            {
                button13.Enabled = false;
            }
            if (NuevaLista[indice].validarAsiento[13] == true)
            {
                button14.Enabled = true;
            }
            else
            {
                button14.Enabled = false;
            }
            if (NuevaLista[indice].validarAsiento[14] == true)
            {
                button15.Enabled = true;
            }
            else
            {
                button15.Enabled = false;
            }
            if (NuevaLista[indice].validarAsiento[15] == true)
            {
                button16.Enabled = true;
            }
            else
            {
                button16.Enabled = false;
            }
        }

        private void FormAsientos_Load(object sender, EventArgs e)
        {
            inicializarBotones();
        }

        private void Comprar_Click(object sender, EventArgs e)
        {
            
           // NuevaLista[indice].asientos = numAsiento;

           this.Close();
        }
    }
}
