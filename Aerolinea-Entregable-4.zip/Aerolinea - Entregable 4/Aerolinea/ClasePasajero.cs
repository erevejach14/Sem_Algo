﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aerolinea
{
    public class ClasePasajero
    {
        public string nombre;
        public string apellido;
        public string edad;
        public int asiento;
        public string vuelo; 

        
        public ClasePasajero(string nom, string apellido, string edad, string asiento, string vuelo)
        {
            nombre = nom;
            this.apellido = apellido;
            this.edad = edad;
            this.asiento = Int32.Parse(asiento);
            this.vuelo = vuelo; 
        }

        public string getNombre()
        {
            return nombre + "    " + apellido; 
        }
        
        public string getAsiento()
        {
            return (asiento).ToString(); 
        }

        public int getNumPasajeros()
        {
            return -1; 
        }
        
        public string getEdad()
        {
            return edad; 
        }

        public string getVuelo()
        {
            return vuelo; 
        }
    }
}
