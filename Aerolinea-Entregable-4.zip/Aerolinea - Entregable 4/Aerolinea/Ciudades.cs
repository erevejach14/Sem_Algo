﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace Aerolinea
{
    public partial class Ciudades : Form
    {
        PaintEventArgs es;
        ListaCiudades listaCiudades = new ListaCiudades();
      //  Grafo grafo; 
        ClaseListaVuelos NuevaLista = new ClaseListaVuelos();
       ClaseListaVuelos vuelosActuales = new ClaseListaVuelos();
        ClaseListaVuelos vuelosTemporales = new ClaseListaVuelos();
        int x, y;
        PaintEventArgs a;

        Image fondo = Image.FromFile(Environment.GetFolderPath(Environment.SpecialFolder.Personal) + @"\Computación\Tercer semestre\Algoritmia\Aerolinea - Entregable 4\Aerolinea\mapa5.jpg");

        Grafo grafoActual;
        public Ciudades(ref ListaCiudades listaCiudades, ref ClaseListaVuelos NuevaLista)
        {
            this.listaCiudades = listaCiudades;
            this.NuevaLista = NuevaLista;
            vuelosTemporales = NuevaLista;
            grafoActual = new Grafo(NuevaLista, listaCiudades); 
            InitializeComponent();
            button1.Enabled = false;
            button2.Enabled = false; 
        }

        private void panel1_MouseClick(object sender, MouseEventArgs e)
        {

            Pen lapiz = new Pen(Color.Pink, 2);
            Pen lapizLinea = new Pen(Color.DarkBlue, 1);
            Rectangle cuadrito = new Rectangle(e.X-15, e.Y-15, 30, 30);
            this.panel1_Paint(sender, a);
            panel1.CreateGraphics().DrawRectangle(lapiz, cuadrito);
          
            x = e.X;
            y = e.Y;

    
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            Pen lapiz = new Pen(Color.Magenta, 2);
            Pen lapizLinea = new Pen(Color.DarkBlue, 1);
            Font letras = new Font("Typo_Pororo B", 13);
            Font letras1 = new Font("Typo_Pororo B", 11);

            SolidBrush colorcito = new SolidBrush(Color.Black);
            SolidBrush colorcito1 = new SolidBrush(Color.Pink);

            AdjustableArrowCap flecha = new AdjustableArrowCap(3,5);
            lapizLinea.CustomEndCap = flecha;

            panel1.CreateGraphics().DrawImageUnscaled(fondo, 0, 0);

            for (int j=0; j<NuevaLista.Count; j++)
            {
                for (int k=0; k<listaCiudades.Count; k++)
                {
                    if(NuevaLista[j].origen == listaCiudades[k].nombre)
                    {
                        for(int l=0; l<listaCiudades.Count; l++)
                        {
                            if (NuevaLista[j].destino==listaCiudades[l].nombre)
                            {
                                panel1.CreateGraphics().DrawLine(lapizLinea, listaCiudades[k].x+15, listaCiudades[k].y+15, listaCiudades[l].x+15, listaCiudades[l].y+15);
                            }
                        }
                    }
                }
            }

            for (int i = 0; i < listaCiudades.Count; i++)
            {
                Rectangle cuadrito = new Rectangle(listaCiudades[i].x, listaCiudades[i].y, 30, 30);
                panel1.CreateGraphics().DrawRectangle(lapiz, cuadrito);
                panel1.CreateGraphics().DrawString(listaCiudades[i].nombre.ToString(), letras, colorcito, listaCiudades[i].x + 6, listaCiudades[i].y + 6);

            }

            for (int i = 0; i < listaCiudades.Count; i++)
            {
                Rectangle cuadrito = new Rectangle(listaCiudades[i].x, listaCiudades[i].y, 30, 30);
                panel1.CreateGraphics().DrawRectangle(lapiz, cuadrito);
                panel1.CreateGraphics().DrawString(listaCiudades[i].nombre.ToString(), letras1, colorcito1, listaCiudades[i].x + 7, listaCiudades[i].y + 6);

            }

            //     panel1.BackgroundImage = Image.FromFile(System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal) + @"\Computación\Tercer semestre\Algoritmia\Aerolinea - Entregable 4\mapa.jpg");

        }

        private void Ciudades_Load(object sender, EventArgs e)
        {
            for (int i=0; i<listaCiudades.Count; i++)
            {
                comboBox1.Items.Add(listaCiudades[i].nombre); 
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string ciudad = comboBox1.Text;
            int posicion = comboBox1.SelectedIndex;
            int numeroDeVuelos = 0; 

            for (int i=0; i<NuevaLista.Count; i++)
            {
                if (NuevaLista[i].origen.ToString() == ciudad || NuevaLista[i].destino.ToString() == ciudad)
                {
                    NuevaLista.Remove(NuevaLista[i]); 
                     i = -1;
                }                                 
            }

            for (int i = 0; i <listaCiudades.Count; i++)
            {
                for (int j = 0; j <NuevaLista.Count; j++)
                {
                    if (listaCiudades[i].nombre == NuevaLista[j].origen || listaCiudades[i].nombre == NuevaLista[j].destino)
                    {
                        numeroDeVuelos++;
                    }
                }


                if (numeroDeVuelos == 0)
                {
                    listaCiudades.Remove(listaCiudades[i]);
                    i = -1;
                }
               else
                {
                    numeroDeVuelos = 0;
                }
            }

            
            comboBox1.Items.Remove(comboBox1.Items[comboBox1.SelectedIndex]);
            this.panel1_Paint(sender, a); 
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            for (int i=0; i<comboBox1.Items.Count; i++)
            {
                if (comboBox1.Text == comboBox1.Items[i].ToString())
                {
                    button2.Enabled = true; 
                }
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            for (int i=0; i<listaCiudades.Count; i++)
            {
                if (textBox1.Text == listaCiudades[i].nombre.ToString())
                {
                    MessageBox.Show("¡Esa ciudad ya existe!");
                    button1.Enabled = false;
                }
               else
                {
                    button1.Enabled = true;
                }
            }
        }

        private void botonKruskal_Click(object sender, EventArgs e)
        {
            this.panel1_Paint(sender, es);
            listBox1.Items.Clear();
            vuelosTemporales.quicksortTiempo(ref vuelosTemporales, 0, vuelosTemporales.Count - 1);
            List<string> conexiones = new List<string>();
            ClaseListaVuelos listaPrometedora = new ClaseListaVuelos();
            Font letra = new Font("Typo_Pororo B", 12);
            SolidBrush color = new SolidBrush(Color.Black);
            Pen lapiz = new Pen(Color.Yellow, 3);
            AdjustableArrowCap flecha = new AdjustableArrowCap(4, 6);
            lapiz.CustomEndCap = flecha;

            for (int i = 0; i < grafoActual.Count; i++)
            {
                conexiones.Add(grafoActual[i].origen);
            }
            for (int i = 0; i < vuelosTemporales.Count; i++)
            {
                for (int j = 0; j < conexiones.Count; j++)
                {
                    if (conexiones[j].Contains(vuelosTemporales[i].origen.ToString()) && !conexiones[j].Contains(vuelosTemporales[i].destino.ToString()))
                    {
                        for (int k = 0; k < conexiones.Count; k++)
                        {
                            if (conexiones[k].Contains(vuelosTemporales[i].destino.ToString()) && !conexiones[k].Contains(vuelosTemporales[i].origen.ToString()))
                            {
                                if (listaPrometedora.Count > 0)
                                {
                                    bool esDestino = false;
                                    for (int l = 0; l < listaPrometedora.Count; l++)
                                    {
                                        if (vuelosTemporales[i].destino == listaPrometedora[l].destino)
                                        {
                                            esDestino = true;
                                        }
                                    }
                                    if (!esDestino)
                                    {
                                        listaPrometedora.Add(vuelosTemporales[i]);
                                        conexiones[j] = conexiones[j] + conexiones[k];
                                        conexiones.Remove(conexiones[k]);
                                        break;
                                    }
                                }
                                else
                                {
                                    listaPrometedora.Add(vuelosTemporales[i]);
                                    conexiones[j] = conexiones[j] + conexiones[k];
                                    conexiones.Remove(conexiones[k]);
                                    break;
                                }
                            }
                        }
                    }
                }
            }
            for(int i = 0; i < listaCiudades.Count; i++)
            {
                for(int j = 0; j < listaPrometedora.Count; j++)
                {
                    if (listaPrometedora[j].origen==listaCiudades[i].nombre)
                    {
                        for (int k=0; k<listaCiudades.Count; k++)
                        {
                            if (listaPrometedora[j].destino==listaCiudades[k].nombre)
                            {
                                panel1.CreateGraphics().DrawLine(lapiz, listaCiudades[i].x+15, listaCiudades[i].y+15, listaCiudades[k].x+15, listaCiudades[k].y+15);


                            }
                        }
                    }
                }
            }

            for (int i=0; i<listaCiudades.Count; i++)
            {
                for (int j=0; j<NuevaLista.Count; j++)
                {
                    if (NuevaLista[j].origen == listaCiudades[i].nombre)
                    {
                        for (int k = 0; k < listaCiudades.Count; k++)
                        {
                            if (NuevaLista[j].destino == listaCiudades[k].nombre)
                            {
                                panel1.CreateGraphics().DrawString(NuevaLista[j].duracion.ToString(), letra, color, (listaCiudades[i].x+listaCiudades[k].x)/2 , (listaCiudades[i].y + listaCiudades[k].y) / 2);


                            }
                        }
                    }
                }
            }

            for (int i = 0; i < listaPrometedora.Count; i++)
            {
             //   MessageBox.Show("De " + listaPrometedora[i].origen + " a " + listaPrometedora[i].destino);
                listBox1.Items.Add("De " + listaPrometedora[i].origen + " a " + listaPrometedora[i].destino);
            }
        }

        private void buttonPrim_Click(object sender, EventArgs e)
        {
            panel1.Refresh();
            listBox1.Items.Clear(); 
            Font letra = new Font("Typo_Pororo B", 12);
            SolidBrush color = new SolidBrush(Color.Black);
            Pen lapiz = new Pen(Color.LimeGreen, 3);
            AdjustableArrowCap flecha = new AdjustableArrowCap(4, 6);
            lapiz.CustomEndCap = flecha;
            ClaseListaVuelos listaFinal = new ClaseListaVuelos();
            ClaseListaVuelos vuelosTemporales = new ClaseListaVuelos();
          
            vuelosActuales = NuevaLista;

            vuelosActuales.quicksortCosto(ref vuelosActuales, 0, vuelosActuales.Count - 1);

            int indice = 0;
            int costoMenor = 0;
            int costoMayor = 0;
            bool esDestino = false;
            Random rand = new Random();
            List<char> nodos = new List<char>();
            while (nodos.Count != grafoActual.Count)
            {
                esDestino = false;
                listaFinal = new ClaseListaVuelos();

                for (int i = 0; i < NuevaLista.Count; i++)
                {
                    vuelosTemporales.Add(vuelosActuales[i]);
                    if (NuevaLista[i].costo > costoMayor)
                    {
                        costoMayor = vuelosActuales[i].costo;
                    }
                }

                indice = rand.Next(vuelosTemporales.Count);
                indice = rand.Next(vuelosTemporales.Count);
                nodos = new List<char>();
                for (int i = 0; i < vuelosTemporales.Count; i++)
                {
                    if (vuelosTemporales[indice].origen != vuelosTemporales[i].origen && vuelosTemporales[indice].destino == vuelosTemporales[i].destino)
                    {
                        esDestino = true;
                        break;
                    }
                }
                if (!esDestino)
                {
                    listaFinal.Add(vuelosTemporales[indice]);
                    nodos.Add(vuelosTemporales[indice].origen);
                    nodos.Add(vuelosTemporales[indice].destino);
                    costoMenor = costoMayor;
                }
                for (int i = 0; i < vuelosTemporales.Count; i++)
                {
                    for (int j = 0; j < vuelosTemporales.Count; j++)
                    {
                        if (vuelosTemporales[i].origen != vuelosTemporales[j].origen && vuelosTemporales[i].destino == vuelosTemporales[j].destino)
                        {
                            vuelosTemporales.Remove(vuelosTemporales[j]);
                            i = -1;
                            break;
                        }
                    }
                    if (i > -1)
                    {
                        if (nodos.Contains(vuelosTemporales[i].origen) && !nodos.Contains(vuelosTemporales[i].destino))
                        {
                            for (int j = 0; j < vuelosTemporales.Count; j++)
                            {
                                if (vuelosTemporales[i].origen == vuelosTemporales[j].origen && !nodos.Contains(vuelosTemporales[j].destino))
                                {
                                    if (vuelosTemporales[j].costo <= costoMenor)
                                    {
                                        costoMenor = vuelosTemporales[j].costo;
                                        indice = j;
                                    }
                                }
                            }
                            if (!listaFinal.Contains(vuelosTemporales[indice]))
                            {
                                listaFinal.Add(vuelosTemporales[indice]);
                                if (!nodos.Contains(vuelosTemporales[indice].origen))
                                {
                                    nodos.Add(vuelosTemporales[indice].origen);
                                }
                                if (!nodos.Contains(vuelosTemporales[indice].destino))
                                {
                                    nodos.Add(vuelosTemporales[indice].destino);
                                }
                            }
                            costoMenor = costoMayor;
                        }
                    }
                }
            }


            for (int i = 0; i < listaCiudades.Count; i++)
            {
                for (int j = 0; j < listaFinal.Count; j++)
                {
                    if (listaFinal[j].origen == listaCiudades[i].nombre)
                    {
                        for (int k = 0; k < listaCiudades.Count; k++)
                        {

                            if (listaCiudades[k].nombre.ToString() == listaFinal[j].destino.ToString())
                            {


                                panel1.CreateGraphics().DrawLine(lapiz, listaCiudades[i].x + 15, listaCiudades[i].y + 15, listaCiudades[k].x + 15, listaCiudades[k].y + 15);
                               // listBox1.Items.Add("De " + listaFinal[i].origen + " a " + listaFinal[i].destino);
                            }
                        } 
                    }
                }
            }

            /*           for (int i = 0; i < grafoActual.Count; i++)
                       {
                           for (int j = 0; j < grafoActual[i].aristasActuales.Count; j++)
                           {
                               //panel1.CreateGraphics().DrawString(grafoActual[i].aristasActuales[j].costo.ToString() + " Mxn", letra, color, ((grafoActual[i].coordenada.X + grafoActual[i].aristasActuales[j].coordenada.X) / 2), ((grafoActual[i].coordenada.Y + grafoActual[i].aristasActuales[j].coordenada.Y) / 2));
                                panel1.CreateGraphics().DrawString(grafoActual[j].aristasActuales[j].costo.ToString() + "Mxn", letra, color, (listaCiudades[i].x + listaCiudades[j].x) / 2, (listaCiudades[i].y + listaCiudades[j].y) / 2);

                           }
                       }*/

            for (int i = 0; i < listaCiudades.Count; i++)
            {
                for (int j = 0; j < NuevaLista.Count; j++)
                {
                    if (NuevaLista[j].origen == listaCiudades[i].nombre)
                    {
                        for (int k = 0; k < listaCiudades.Count; k++)
                        {
                            if (NuevaLista[j].destino == listaCiudades[k].nombre)
                            {
                                panel1.CreateGraphics().DrawString(NuevaLista[j].costo.ToString(), letra, color, (listaCiudades[i].x + listaCiudades[k].x) / 2, (listaCiudades[i].y + listaCiudades[k].y) / 2);


                            }
                        }
                    }
                }
            }

            for (int i = 0; i < listaFinal.Count; i++)
            {
               // MessageBox.Show("De " + listaFinal[i].origen + " a " + listaFinal[i].destino);
                listBox1.Items.Add("De " + listaFinal[i].origen + " a " + listaFinal[i].destino);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("La ciudad no tendrá vuelos, ¿desea continuar? ^^", "", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Ciudad ciudad = new Ciudad(Convert.ToChar(textBox1.Text), x, y);
                listaCiudades.Add(ciudad);
                this.Close();
            }
            else
            {
                MessageBox.Show("Ciudad no agregada ^^"); 
            } 
        }
    }
}
