﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aerolinea
{
    public partial class Vuelos : Form
    {
        /*public int indice;
        string vuelo;*/
        ClaseListaVuelos NuevaLista = new ClaseListaVuelos();
        ClaseListaPasajeros ListaPasajeros = new ClaseListaPasajeros();
        ListaCiudades listaCiudades = new ListaCiudades();
        public Vuelos(ref ClaseListaVuelos NuevaLista, ref ClaseListaPasajeros ListaPasajeros, ref ListaCiudades listaCiudades)
        {
            this.NuevaLista = NuevaLista;
            this.ListaPasajeros = ListaPasajeros;
            this.listaCiudades = listaCiudades; 
            InitializeComponent();
            ActualizaListBox();
        }

        private void botonComprar_Click(object sender, EventArgs e)
        {
           // this.Hide();

            int indice = listBoxVuelos.SelectedIndex;
            string cad=listBoxVuelos.SelectedItem.ToString();
            FormFormulario ventanaFormulario = new FormFormulario(ref NuevaLista, ref ListaPasajeros, indice);

            ventanaFormulario.ShowDialog();
            this.Close();
        }

        private void ActualizaListBox()
        {
            listBoxVuelos.Items.Clear();
            for (int i = 0; i < NuevaLista.Count; i++)
            {
                listBoxVuelos.Items.Add(NuevaLista[i]);
            }
        }

        private void Vuelos_Load(object sender, EventArgs e)
        {
            //ActualizaListBox();
        }

        private void listBoxVuelos_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBoxVuelos.SelectedItem.Equals(-1))
            {
                botonComprar.Enabled = false;
            }
            else
            {
                botonComprar.Enabled = true; 
            }
        }

        private void buttonAgregar_Click(object sender, EventArgs e)
        {
            FormAgregarVuelo agregaVuelo = new FormAgregarVuelo(ref NuevaLista, ref listaCiudades);
            agregaVuelo.ShowDialog();
        }

        private void Vuelos_Activated(object sender, EventArgs e)
        {
            ActualizaListBox();
        }

        private void button3_Click(object sender, EventArgs e)
        {

            int indice = listBoxVuelos.SelectedIndex;
            NuevaLista.Remove(NuevaLista[indice]);
            listBoxVuelos.Items.Clear(); 
            ActualizaListBox();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            DateTime fechaActual = DateTime.Today;
            bool actualizado = false; 

            while (actualizado==false)
            {
                actualizado = true; 
                for (int i=0; i<NuevaLista.Count; i++)
                {
                    int comparando= DateTime.Compare(NuevaLista[i].fecha, fechaActual);
                    if (comparando <0)
                    {
                        NuevaLista.Remove(NuevaLista[i]);
                        ActualizaListBox();
                    } 

                }

            }
        }
    }
}
