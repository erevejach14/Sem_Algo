﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aerolinea
{
    public partial class FormVuelos : Form
    {
        public int indice;
        string vuelo, vuelos;


        ClaseListaVuelos NuevaLista = new ClaseListaVuelos();
        ClaseListaPasajeros ListaPasajeros = new ClaseListaPasajeros();
        public FormVuelos(ref ClaseListaVuelos NuevaLista, ref ClaseListaPasajeros ListaPasajeros)
        {
            this.NuevaLista = NuevaLista; 
            InitializeComponent();

        }

        public void QuickSortAsientos(ref ClaseListaVuelos NuevaLista, int first, int last)
        {
            int i = first;
            int j = last;
            int central;
            int pivote;

            central = (first + last) / 2;
            pivote = NuevaLista[central].asientosDisp;

            while (i <= j)
            {
                while (NuevaLista[i].asientosDisp > pivote) { i++; }
                while (NuevaLista[j].asientosDisp < pivote) { j--; }

                if (i <= j)
                {
                    ClaseVuelos temp = NuevaLista[i];
                    NuevaLista[i] = NuevaLista[j];
                    NuevaLista[j] = temp;           
                    i++;
                    j--;
                }
            }

            if (first < j)
            {
                QuickSortAsientos(ref NuevaLista, first, j);
            }
            if (i < last)
            {
                QuickSortAsientos(ref   NuevaLista, i, last);
            }
        }

        public void QuickSortFecha(ref ClaseListaVuelos NuevaLista, int posicionInicialLista, int posicionFinalLista)
        {
            int i = posicionInicialLista;
            int j = posicionFinalLista;
            int central;
            DateTime pivote;

            central = (posicionInicialLista + posicionFinalLista) / 2;
            pivote = NuevaLista[central].fecha;

            while (i <= j)
            {
                while (NuevaLista[i].fecha < pivote) { i++; }
                while (NuevaLista[j].fecha > pivote) { j--; }

                if (i <= j)
                {
                    ClaseVuelos temp = NuevaLista[i];
                    NuevaLista[i] = NuevaLista[j];
                    NuevaLista[j] = temp;
                    i++;
                    j--;
                }
            }

            if (posicionInicialLista < j)
            {
                QuickSortFecha(ref NuevaLista, posicionInicialLista, j);
            }
            if (i < posicionFinalLista)
            {
                QuickSortFecha(ref NuevaLista, i, posicionFinalLista);
            }
        }

        private void FormVuelos_Load(object sender, EventArgs e)
        {
            for(int i=0; i<NuevaLista.Count; i++)
            {
                ListViewItem vuelo = new ListViewItem(NuevaLista[i].ruta);
                vuelo.SubItems.Add(NuevaLista[i].fecha.ToString());
                vuelo.SubItems.Add(NuevaLista[i].origen.ToString());
                vuelo.SubItems.Add(NuevaLista[i].destino.ToString());
                vuelo.SubItems.Add(NuevaLista[i].costo.ToString());
                vuelo.SubItems.Add(NuevaLista[i].asientosDisp.ToString());
                listVuelos.Items.Add(vuelo);
            }
        }


        private void button1_Click(object sender, EventArgs e)
        {
            QuickSortFecha(ref NuevaLista, 0, NuevaLista.Count - 1);
            listVuelos.Items.Clear();
            for (int i = 0; i < NuevaLista.Count; i++)
            {
                ListViewItem vuelo = new ListViewItem(NuevaLista[i].ruta);
                vuelo.SubItems.Add(NuevaLista[i].fecha.ToString());
                vuelo.SubItems.Add(NuevaLista[i].origen.ToString());
                vuelo.SubItems.Add(NuevaLista[i].destino.ToString());
                vuelo.SubItems.Add(NuevaLista[i].costo.ToString());
                vuelo.SubItems.Add(NuevaLista[i].asientosDisp.ToString());
                listVuelos.Items.Add(vuelo);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            QuickSortAsientos(ref NuevaLista, 0, NuevaLista.Count - 1);
            listVuelos.Items.Clear();
            for (int i = 0; i < NuevaLista.Count; i++)
            {
                ListViewItem vuelo = new ListViewItem(NuevaLista[i].ruta);
                vuelo.SubItems.Add(NuevaLista[i].fecha.ToString());
                vuelo.SubItems.Add(NuevaLista[i].origen.ToString());
                vuelo.SubItems.Add(NuevaLista[i].destino.ToString());
                vuelo.SubItems.Add(NuevaLista[i].costo.ToString());
                vuelo.SubItems.Add(NuevaLista[i].asientosDisp.ToString());
                listVuelos.Items.Add(vuelo);
            }
        }


        private void listVuelos_SelectedIndexChanged(object sender, EventArgs e)
        {
            for (int i = 0; i < listVuelos.Items.Count; i++)
            {
                if (listVuelos.Items[i].Selected)
                {
                   // indice = listVuelos.Items.SubItems[].Text;
                    vuelo = listVuelos.Items[i].SubItems[0].Text;
                    break;
                }
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            vuelos = textBox1.Text;
            listVuelos.Items.Clear();
            for (int i=0; i<NuevaLista.Count; i++)
            {
          
                if (NuevaLista[i].ruta.Contains(vuelos))
                {

                        ListViewItem vuelo = new ListViewItem(NuevaLista[i].ruta);
                        vuelo.SubItems.Add(NuevaLista[i].fecha.ToString());
                        vuelo.SubItems.Add(NuevaLista[i].origen.ToString());
                        vuelo.SubItems.Add(NuevaLista[i].destino.ToString());
                        vuelo.SubItems.Add(NuevaLista[i].costo.ToString());
                        vuelo.SubItems.Add(NuevaLista[i].asientosDisp.ToString());
                        listVuelos.Items.Add(vuelo);
                }
               
            }

            
        }
    }
}
