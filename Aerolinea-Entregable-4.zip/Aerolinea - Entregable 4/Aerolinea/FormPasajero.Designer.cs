﻿namespace Aerolinea
{
    partial class FormPasajero
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormPasajero));
            this.buttonEliminar = new System.Windows.Forms.Button();
            this.listViewPasajero = new System.Windows.Forms.ListView();
            this.indice = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.indicePasajero = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.vuelo = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.nombre = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.asiento = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // buttonEliminar
            // 
            this.buttonEliminar.Font = new System.Drawing.Font("Futura Bk BT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonEliminar.ForeColor = System.Drawing.Color.DarkMagenta;
            this.buttonEliminar.Location = new System.Drawing.Point(320, 13);
            this.buttonEliminar.Name = "buttonEliminar";
            this.buttonEliminar.Size = new System.Drawing.Size(145, 32);
            this.buttonEliminar.TabIndex = 1;
            this.buttonEliminar.Text = "Eliminar pasajero";
            this.buttonEliminar.UseVisualStyleBackColor = true;
            this.buttonEliminar.Click += new System.EventHandler(this.buttonEliminar_Click);
            // 
            // listViewPasajero
            // 
            this.listViewPasajero.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.indice,
            this.indicePasajero,
            this.vuelo,
            this.nombre,
            this.asiento});
            this.listViewPasajero.Font = new System.Drawing.Font("Futura Bk BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listViewPasajero.FullRowSelect = true;
            this.listViewPasajero.GridLines = true;
            this.listViewPasajero.Location = new System.Drawing.Point(13, 13);
            this.listViewPasajero.Name = "listViewPasajero";
            this.listViewPasajero.Size = new System.Drawing.Size(290, 267);
            this.listViewPasajero.TabIndex = 0;
            this.listViewPasajero.UseCompatibleStateImageBehavior = false;
            this.listViewPasajero.View = System.Windows.Forms.View.Details;
            this.listViewPasajero.SelectedIndexChanged += new System.EventHandler(this.listViewPasajero_SelectedIndexChanged);
            // 
            // indice
            // 
            this.indice.Text = "Indice";
            this.indice.Width = 0;
            // 
            // indicePasajero
            // 
            this.indicePasajero.Text = "Pasajero";
            this.indicePasajero.Width = 0;
            // 
            // vuelo
            // 
            this.vuelo.Text = "Vuelo";
            // 
            // nombre
            // 
            this.nombre.Text = "Nombre";
            this.nombre.Width = 150;
            // 
            // asiento
            // 
            this.asiento.Text = "Asiento";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(320, 92);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(129, 20);
            this.textBox1.TabIndex = 2;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Futura Md BT", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.MediumPurple;
            this.label1.Location = new System.Drawing.Point(316, 70);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(133, 19);
            this.label1.TabIndex = 5;
            this.label1.Text = "Buscar pasajero: ";
            // 
            // FormPasajero
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(498, 292);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.listViewPasajero);
            this.Controls.Add(this.buttonEliminar);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormPasajero";
            this.Text = "Pasajeros";
            this.Load += new System.EventHandler(this.FormPasajero_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button buttonEliminar;
        private System.Windows.Forms.ListView listViewPasajero;
        private System.Windows.Forms.ColumnHeader indice;
        private System.Windows.Forms.ColumnHeader indicePasajero;
        private System.Windows.Forms.ColumnHeader vuelo;
        private System.Windows.Forms.ColumnHeader nombre;
        private System.Windows.Forms.ColumnHeader asiento;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
    }
}