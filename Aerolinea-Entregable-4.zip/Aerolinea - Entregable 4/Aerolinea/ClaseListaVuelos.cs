﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace Aerolinea
{
    public class ClaseListaVuelos:List <ClaseVuelos>
    {

        public void guardar()
        {

            StreamWriter writer = new StreamWriter("Vuelos.txt");
            foreach (ClaseVuelos v in this)
            {
                writer.WriteLine(v.ToString()); 
            }
            writer.Close();
        }

        public void cargar()
        {
            ClaseVuelos v = new ClaseVuelos();
            StreamReader reader = new StreamReader("Vuelos.txt"); 
            while(!reader.EndOfStream)
            {
                string cad = reader.ReadLine();
                
            }
            this.Add(v); 
        }


        public void quicksortTiempo(ref ClaseListaVuelos NuevaLista, int inicio, int fin)
        {
            int i=inicio;
            int j=fin;
            int central;
            int pivote;

            central = (inicio + fin) / 2;
            pivote = NuevaLista[central].duracion;

            if (inicio >= fin)
            {
                return;
            }

            while (i <= j)
            {
                while (NuevaLista[i].duracion < pivote)
                {
                    i++;
                }
                while (NuevaLista[j].duracion > pivote)
                {
                    j--;
                }
                if (i <= j)
                {
                    ClaseVuelos temp = NuevaLista[i];
                    NuevaLista[i] = NuevaLista[j];
                    NuevaLista[j] = temp;
                    i++;
                    j--;
                }
            }
            if (inicio < j)
            {
                quicksortTiempo(ref NuevaLista, inicio, j);
            }
            if (i < fin)
            {
                quicksortTiempo(ref NuevaLista, i, fin);
            }
        }
        public void quicksortCosto(ref ClaseListaVuelos vuelosActuales, int inicio, int fin)
        {
            int i;
            int j;
            int central;
            int pivote;

            i = inicio;
            j = fin;
            central = (inicio + fin) / 2;
            pivote = vuelosActuales[central].costo;

            if (inicio >= fin)
            {
                return;
            }

            while (i <= j)
            {
                while (vuelosActuales[i].costo < pivote)
                {
                    i++;
                }
                while (vuelosActuales[j].costo > pivote)
                {
                    j--;
                }
                if (i <= j)
                {
                    ClaseVuelos temp = vuelosActuales[i];
                    vuelosActuales[i] = vuelosActuales[j];
                    vuelosActuales[j] = temp;
                    i++;
                    j--;
                }
            }
            if (inicio < j)
            {
                quicksortCosto(ref vuelosActuales, inicio, j);
            }
            if (i < fin)
            {
                quicksortCosto(ref vuelosActuales, i, fin);
            }
        }

        /*     public string toStringO()
             {
                 string asientos = ""; 
                 for (int i=0;  i<asientoDisp.Lenght; i++)
                 {
                     if (asientosDisp[i]==false)
                     {
                         asientos +=i+"|";
                     }
                 }
                 return origen.ToString() + destino.toString() + asientos; 
             }*/

    }
}
